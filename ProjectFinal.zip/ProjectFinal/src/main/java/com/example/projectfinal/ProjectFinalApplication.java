package com.example.projectfinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectFinalApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjectFinalApplication.class, args);
    }

}
